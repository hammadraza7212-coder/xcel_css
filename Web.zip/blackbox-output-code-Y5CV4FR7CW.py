from flask import Blueprint, jsonify, request
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from app.models import db, User
from app.services.gamification import calculate_level

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/stats', methods=['GET'])
@jwt_required()
def get_stats():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    return jsonify({
        'name': user.name,
        'xp': user.xp_points,
        'level': user.level,
        'hours': user.study_hours,
        'streak': user.streak_days,
        'proficiency': user.proficiency_score
    })

@dashboard_bp.route('/update-xp', methods=['POST'])
@jwt_required()
def update_xp():
    user_id = get_jwt_identity()
    data = request.get_json()
    xp_gain = data.get('xp', 0)
    
    user = User.query.get(user_id)
    user.xp_points += xp_gain
    user.level = calculate_level(user.xp_points)
    
    db.session.commit()
    return jsonify({'message': 'XP Updated', 'new_level': user.level}), 200