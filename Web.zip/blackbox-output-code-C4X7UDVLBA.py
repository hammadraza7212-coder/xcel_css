def calculate_level(xp):
    """Determines level based on XP thresholds."""
    if xp < 100: return "Beginner"
    elif xp < 300: return "Intermediate"
    elif xp < 600: return "Advanced"
    elif xp < 1000: return "Elite Aspirant"
    else: return "Super Topper"

def calculate_xp(is_correct, difficulty):
    """XP Calculation Logic"""
    base_xp = 10
    if difficulty == 'Hard': base_xp += 10
    return base_xp if is_correct else 0