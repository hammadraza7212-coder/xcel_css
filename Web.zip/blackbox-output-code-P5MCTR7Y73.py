from flask import Flask
from config import Config
from app.models import db
from flask_jwt_extended import JWTManager

jwt = JWTManager()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    jwt.init_app(app)

    # Register Blueprints
    from app.routes.auth import auth_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.quiz import quiz_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(dashboard_bp, url_prefix='/api/dashboard')
    app.register_blueprint(quiz_bp, url_prefix='/api/quiz')

    with app.app_context():
        db.create_all()
        # Seed initial data logic here
        
    return app