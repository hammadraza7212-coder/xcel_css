import os
from datetime import timedelta

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-elite'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///elite_prep.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT Settings
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET') or 'jwt-secret-elite'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)

    # AI Configuration (Placeholder)
    AI_PROVIDER = os.environ.get('AI_PROVIDER', 'OPENAI') 
    AI_API_KEY = os.environ.get('AI_API_KEY', '')